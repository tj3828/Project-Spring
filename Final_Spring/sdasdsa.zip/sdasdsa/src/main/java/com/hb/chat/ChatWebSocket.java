package com.hb.chat;

public class ChatWebSocket {

}
