package com.hb.chat;

import org.apache.ibatis.annotations.Insert;

public interface IChatDAOMapper {
	
	@Insert("insert into chatting values("
			+ "chatting_seq.nextval, "
			+ "#{fromNick}, "
			+ "#{toNick},"
			+ "to_date(#{writeDate},'YY/MM/DD HH24:MI'),"
			+ "#{content},"
			+ "#{readCheck}"
			+ ")")
	void insertMessage(ChatVO dto);
}
