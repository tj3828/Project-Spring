package com.hb.chat;

import org.springframework.stereotype.Service;


public interface IChatService {
	void insertMessage(ChatVO dto);
}
